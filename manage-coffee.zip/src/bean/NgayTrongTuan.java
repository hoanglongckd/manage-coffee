package bean;

public class NgayTrongTuan {

		private String tenNgay;

		public String getTenNgay() {
			return tenNgay;
		}

		public void setTenNgay(String tenNgay) {
			this.tenNgay = tenNgay;
		}

		public NgayTrongTuan(String tenNgay) {
			super();
			this.tenNgay = tenNgay;
		}

		public NgayTrongTuan() {
			super();
			// TODO Auto-generated constructor stub
		}
		
		
}
