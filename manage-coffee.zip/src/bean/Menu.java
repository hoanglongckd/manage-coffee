package bean;

public class Menu {
	private int id_Menu;
	private int id_picture;
	private int id_Shop;
	private int id_type_Menu;
	private  int id_Cost;
	private  int kieuchebien;

}
